# DEPLOYER une Function as a Service (FaaS)

# Source

C'est le code où l'application de type FaaS est compilée. L'image du conteneur est gérée par un Makefile, ce qui permet d'automatiser et de rendre plus fiable la création de mon artefact.
Vous pouvez après avoir jeter un coup d'oeil, acceder à l'image docker: maissacrement/azure-functionapp

# DEPLOY

Déploiement des conteneurs FaaS vers le cloud