# Mise en oeuvre d'une configuration Nginx en temps réel sur Docker

Description : Cet exemple démontre la mise en œuvre d'une configuration Nginx en temps réel dans un conteneur Docker.

# Comment utiliser ?

Une fois avoir modifier les fichiers de configuration 'nginx.conf' ou/et 'server.conf'

```bash
make up # s'attache sur l'interface de votre machine directement
```